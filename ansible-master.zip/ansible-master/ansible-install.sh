#!/bin/bash
sudo apt update
sudo apt install software-properties-common -í
sudo apt-add-repository ppa:ansible/ansible
sudo apt update
sudo apt install ansible -y
sudo apt install openssh-server -y
